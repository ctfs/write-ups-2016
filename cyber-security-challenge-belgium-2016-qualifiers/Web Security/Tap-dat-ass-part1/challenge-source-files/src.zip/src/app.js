var server = require('http').createServer();
var url = require('url');
var WebSocketServer = require('ws').Server;
var wss = new WebSocketServer({"server": server});
var express = require('express');
var app = express();
var crypto = require('crypto');
var port = 4080;
var Promise = require('promise');
var config = require('./config.json');
var mysql = require('mysql');
var util = require("util");

var pool = mysql.createPool({
	host     : config.mysql_host,
	user     : config.mysql_user,
	password : config.mysql_pass,
	database : config.mysql_name
});
var flag = config.flag;


process.on('uncaughtException', function (exception) {
	console.log(util.inspect(exception));
});

app.use(express.static('public'));

var gameInfo = {};
gameInfo.round = 1;
gameInfo.startTime = 0;
gameInfo.roundDuration = 1000*60*2;
// gameInfo.roundDuration = 1000*20;
gameInfo.scores = {};
gameInfo.playerNames = {};
gameInfo.difficulties = {};

function escapeStr(str) {
	return str.replace("'", '').replace('"', '').replace('/*', '').replace('#', '').replace('--', '').replace('%', '').replace(';', '');
}

function startNewRound() {
	gameInfo.startTime = (new Date()).getTime();
	gameInfo.round = gameInfo.round + 1;
	gameInfo.scores = {};
	setTimeout(endRound, gameInfo.roundDuration);
	try {
		wss.clients.forEach(function each(client) {
			client.send(JSON.stringify({
				"action": "newRound",
				"parameter": {
					"roundNumber": gameInfo.round,
					"duration": gameInfo.roundDuration
				}
			}));
		});
	} catch(e) {
		console.log('Error starting new round...', util.inspect(e));
	}
}

function sendUpdate() {
	try {
		var scoreList = Object.keys(gameInfo.scores).map(function(teamId) {
			return {
				"name": gameInfo.playerNames[teamId],
				"score": gameInfo.scores[teamId]
			}
		});
		wss.clients.forEach(function each(client) {
			client.send(JSON.stringify({
				"action": "update",
				"parameter": {
					"highScores": scoreList,
					"timeLeft": gameInfo.roundDuration - ((new Date()).getTime() - gameInfo.startTime),
					"round": gameInfo.round
				}
			}));
		});
	} catch(e) {
		console.log('Error sending update...', util.inspect(e));
	}
}

function endRound() {
	try {
		sendUpdate();
		wss.clients.forEach(function each(client) {
			client.send(JSON.stringify({
				"action": "endRound",
				"parameter": {
					"round": gameInfo.round,
					"nextRound": 5000
				}
			}));
		});
		var highscoreRows = Object.keys(gameInfo.scores).map(function(playerId) {
			return [playerId, gameInfo.playerNames[playerId], gameInfo.scores[playerId], gameInfo.round];
		});
		// add entries to database
		pool.getConnection(function(err, connection) {
			connection.query("INSERT INTO highscores (playerId, playerName, score, round) VALUES ?", [highscoreRows], function(err) {
				connection.release();
			});
		});
	} catch(e) {
		console.log('Error ending round...', util.inspect(e));
	}
	setTimeout(startNewRound, 5000);

}

function getRandom() {
	return new Promise(function(resolve) {
		crypto.randomBytes(16, function(ex, buf) {
			resolve(buf.toString('hex'));
		});
	})
}

wss.on('connection', function connection(ws) {
	function sendWSMessage(msg) {
		ws.send(JSON.stringify(msg));
	}

	function register(name) {
		try {
			getRandom().then(function(uniqueId) {
				pool.getConnection(function(err, connection) {
					// Use the connection
					connection.query("INSERT INTO difficulties SET ?", {
						"playerId": uniqueId,
						"difficulty": 1
					}, function(err, rows) {
						connection.release();
					});
				});
				gameInfo.scores[uniqueId] = 0;
				gameInfo.playerNames[uniqueId] = name;
				gameInfo.difficulties[uniqueId] = 1;
				sendWSMessage({
					"action": "completeRegistration",
					"parameter": uniqueId
				});
			});
		} catch(e) {
			console.log('Could not register...', util.inspect(e));
		}
	}

	function increaseScore(param) {
		try {
			if (param && param.playerId && param.roundNumber === gameInfo.round) {
				if (gameInfo.scores[param.playerId] !== undefined && gameInfo.difficulties[param.playerId] !== undefined) {
					gameInfo.scores[param.playerId] = gameInfo.scores[param.playerId] + gameInfo.difficulties[param.playerId];
				}
				else if (gameInfo.difficulties[param.playerId] !== undefined) {
					gameInfo.scores[param.playerId] = gameInfo.difficulties[param.playerId];
				}
				else {
					gameInfo.scores[param.playerId] = 1;
					gameInfo.difficulties[param.playerId] = 1;
				}
				console.log('Increased score of ' + param.playerId + ' to ' + gameInfo.scores[param.playerId]);
				if (gameInfo.scores[param.playerId] > 9000) {
					// score is OVER 9000!
					sendWSMessage({
						"action": "firstFlag",
						"parameter": flag
					});
				}
			}
		} catch(e) {
			console.log('Error increasing score...', util.inspect(e));
		}
	}

	function updateDifficulty(param) {
		try {
			if (param && param.playerId && param.difficulty) {
				// make sure difficulty is valid value
				if (parseInt(param.difficulty) > 0) {
					gameInfo.difficulties[param.playerId] = param.difficulty;
					pool.getConnection(function(err, connection) {
						connection.query('UPDATE difficulties SET difficulty = ' + escapeStr(param.difficulty) + " WHERE playerId = '" + escapeStr(param.playerId + "'"), function(err, result) {
							console.log('Updated difficulty for ' + param.playerId + ' to ' + param.difficulty);
							connection.release();
						});
					});
				}
			}
		} catch(e) {
			// do nothing
			console.log('Error updating difficulty');
		}
	}

	function getDifficulty(playerId) {
		try {
			pool.getConnection(function(err, connection) {
				connection.query('SELECT difficulty FROM difficulties WHERE playerId = ' + mysql.escape(playerId), function(err, rows, fields) {
					if (!err) {
						sendWSMessage({
							"action": "receiveDifficulty",
							"parameter": rows[0].difficulty
						});
					}
					connection.release();
				});
			});
		} catch(e) {
			console.log('Error getting difficulty...', util.inspect(e));
		}
	}

	function handleMessage(msg) {
		if (msg) {
			var data = JSON.parse(msg);
			if (data && data.action && data.parameter) {
				var action = data.action;
				console.log('Handling action', action);
				if (action in SWHandlers) {
					SWHandlers[action].call(this, data.parameter);
				}
				else {
					console.log('Undefined action', action);
				}
			}
			else {
				console.log(data);
			}
		}
		else {
			console.log('Unknown message', util.inspect(msg));
		}
	}

	var SWHandlers = {
		"register": register,
		"updateDifficulty": updateDifficulty,
		"increaseScore": increaseScore,
		"getDifficulty": getDifficulty
	};

	ws.on('message', handleMessage);
});

server.on('request', app);
server.listen(port, function () {
	console.log('Listening on ' + server.address().port)
});

startNewRound();
setInterval(sendUpdate, 500);
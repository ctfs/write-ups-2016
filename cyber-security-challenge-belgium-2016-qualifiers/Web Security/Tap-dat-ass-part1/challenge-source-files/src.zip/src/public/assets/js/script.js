(function() {
	var moveInterval;
	var ass = document.querySelector('.inner img');
	var assPixels;
	var ws;
	var gameState = {
		"tapable": true
	};
	var difficulty = 1;

	function getName() {
		return document.querySelector('.inner input').value;
	}

	var scoreHandler = (function() {
		var score = 0;
		function increase() {
			score += difficulty;
			document.getElementById('score').textContent = score;
		}
		function send() {
			sendWSMessage({
				"action": "increaseScore",
				"parameter": {
					"playerId": gameState.playerId,
					"roundNumber": gameState.round
				}
			});
		}
		function reset() {
			score = 0;
			document.getElementById('score').textContent = 0;
		}
		return {
			"increase": increase,
			"send": send,
			"reset": reset
		};
	})();

	function moveDatAss() {
		var newLocation = getRandomAssLocation();
		ass.style.left = newLocation.x + 'px';
		ass.style.top = newLocation.y + 'px';
	}

	function checkCollision(e) {
		var assPosition = $(ass).offset();
		var mousePos = {x : e.pageX - Math.floor(assPosition.left), y : e.pageY - Math.floor(assPosition.top)};
		var alphaLoc = ((assPixels.width * mousePos.y) + mousePos.x) * 4;
		//console.log(mousePos, alphaLoc, assPixels.data[alphaLoc], assPixels.data[alphaLoc+1], assPixels.data[alphaLoc+2], assPixels.data[alphaLoc+3]);
		return assPixels.data[alphaLoc] !== 0;
	}

	function getAssCanvas() {
		var assCanvas = document.createElement('canvas');
		assCanvas.width = ass.width;
		assCanvas.height = ass.height;
		var ctx = assCanvas.getContext('2d');
		ctx.drawImage(ass, 0, 0);
		assPixels = ctx.getImageData(0, 0, ass.width, ass.height);
	}

	function startGame() {
		document.querySelector('.inner .before-start').style.visibility = 'hidden';
		document.querySelector('.difficulty-picker').className = document.querySelector('.difficulty-picker').className.replace('hidden', '');
		ass.className = '';
		getAssCanvas();
		moveDatAss();
		moveInterval = setInterval(moveDatAss, 1000/difficulty);
	}

	function endRound() {
		gameState.tapable = false;
		clearInterval(moveInterval);
		moveInterval = false;
	}

	function newRound() {
		gameState.tapable = true;
		if (!moveInterval) {
			moveInterval = setInterval(moveDatAss, 1000/difficulty);
		}
		scoreHandler.reset();
	}

	function getRandomAssLocation() {
		var gameRects = document.querySelector('.inner').getBoundingClientRect();
		var assRects = ass.getBoundingClientRect();
		var randomX = Math.random() * (gameRects.width - assRects.width);
		var randomY = Math.random() * (gameRects.height - assRects.height);
		return {
			"x": Math.floor(randomX),
			"y": Math.floor(randomY)
		};
	}

	function tap(e) {
		if (gameState.tapable && checkCollision(e)) {
			gameState.tapable = false;
			clearInterval(moveInterval);
			moveInterval = false;
			document.getElementById('ass').style.transform = 'rotate(270deg)';
			document.getElementById('ass').style.filter = 'invert(100%)';
			document.getElementById('ass').style.WebkitFilter = 'invert(100%)';
			setTimeout(function() {
				document.getElementById('ass').style.transform = '';
			}, 1000);
			setTimeout(function() {
				document.getElementById('ass').style.filter = '';
				document.getElementById('ass').style.WebkitFilter = '';
				gameState.tapable = true;
				moveDatAss();
				if (!moveInterval) {
					moveInterval = setInterval(moveDatAss, 1000/difficulty);
				}
			}, 2000);
			scoreHandler.increase();
			scoreHandler.send();
		}
	}

	function completeRegistration(playerId) {
		gameState.playerId = playerId;
		console.log('Registration complete!', playerId);
		window.localStorage.playerId = playerId;
		startGame();
	}

	function update(data) {
		document.getElementById('round-nr').textContent = data.round;
		gameState.round = data.round;

		if (data.timeLeft < 0) {
			document.getElementById('time-left').textContent = 'xx:xx';
		}
		else {
			var mins = Math.floor(data.timeLeft / 1000 / 60);
			mins = mins < 10 ? '0' + mins : mins + '';
			var secs = Math.floor(data.timeLeft / 1000) % 60;
			secs = secs < 10 ? '0' + secs : secs + '';
			document.getElementById('time-left').textContent = mins + ':' + secs;
		}

		if (data.highScores) {
			var tbody = document.querySelector('.highscores tbody');
			while (tbody.firstChild) {
				tbody.removeChild(tbody.firstChild);
			}
			data.highScores.sort(function(a, b) {
				return b.score - a.score;
			});
			for (var i = 0, n = data.highScores.length; i < n; i++) {
				var tr = document.createElement('tr');
				var td1 = document.createElement('td');
				var td2 = document.createElement('td');
				td1.textContent = data.highScores[i].name;
				td2.textContent = data.highScores[i].score;
				tr.appendChild(td1);
				tr.appendChild(td2);
				tbody.appendChild(tr);
			}
		}
	}

	function handleWSMessage(msg) {
		if (msg && msg.data) {
			var data = JSON.parse(msg.data);
			if (data && data.action && data.parameter) {
				if (data.action in SWHandlers) {
					console.log('Handling action', data.action);
					SWHandlers[data.action].call(this, data.parameter);
				}
				else {
					console.log('Undefined action', data);
				}
			}
			else {
				console.log('No data?', data);
			}
		}
		else {
			console.log('Unknown message', msg);
		}
	}


	function setupWebSocket() {
		return new Promise(function(resolve, reject) {
			ws = new WebSocket('ws://' + window.location.hostname + ':' + window.location.port + '/ass-tapping');
			ws.addEventListener('message', handleWSMessage);
			ws.addEventListener('open', resolve);
			ws.addEventListener('error', reject);
		});
	}

	function sendWSMessage(msg) {
		if (ws && ws.readyState === 1) {
			ws.send(JSON.stringify(msg));
		}
		else {
			alert('There was an error with the WebSocket, please try connecting again...');
		}
	}

	function register(name) {
		window.localStorage.name = name;
		sendWSMessage({
			"action": "register",
			"parameter": name
		});
	}

	function updateDifficulty() {
		var newDifficulty = parseInt(document.querySelector('.difficulty-picker input').value, 10);
		sendWSMessage({
			"action": "updateDifficulty",
			"parameter": {
				"playerId": gameState.playerId,
				"difficulty": newDifficulty
			}
		});
		difficulty = newDifficulty;
		clearInterval(moveInterval);
		moveInterval = false;
		moveInterval = setInterval(moveDatAss, 1000/difficulty);
	}

	function receiveDifficulty(newDifficulty) {
		difficulty = newDifficulty;
		document.querySelector('.difficulty-picker input').value = difficulty;
		clearInterval(moveInterval);
		moveInterval = false;
		moveInterval = setInterval(moveDatAss, 1000/difficulty);
	}

	function firstFlag(flag) {
		alert('Whoah, you did it! You have a score over 9000! You definitely deserve the flag now: ' + flag);
	}

	var SWHandlers = {
		"completeRegistration": completeRegistration,
		"update": update,
		"endRound": endRound,
		"newRound": newRound,
		"firstFlag": firstFlag,
		"receiveDifficulty": receiveDifficulty
	}

	window.addEventListener('load', function() {
		setupWebSocket().then(function() {
			if (window.localStorage.playerId !== undefined) {
				gameState.playerId = window.localStorage.playerId;
				sendWSMessage({
					"action": "getDifficulty",
					"parameter": gameState.playerId
				});
				startGame();
			}
			console.log('WebSocket set up');
			document.querySelector('.inner button').addEventListener('click', function() {
				var name = getName();
				if (name && name.length > 1) {
					register(name);
				}
			});
			document.querySelector('.inner input').addEventListener('input', function() {
				var button = document.querySelector('.inner button');
				var name = getName();
				if (name && name.length > 1) {
					button.className = button.className.replace('disabled', '');
				}
			});
			document.querySelector('.difficulty-picker input').addEventListener('input', updateDifficulty);
			$(ass).bind('click', tap);
		}).catch(function() {
			alert('There was an error setting up the WebSocket!');
		});
	});
})();
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
using System.Data.SqlClient;
using System.Configuration;
using Shit;
using System.Data.SQLite;

public partial class Admin : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Request.ServerVariables["REMOTE_ADDR"] == "127.0.0.1")
        {
            AdminModel admin = null;
            if (Request.Cookies["Session"] != null)
            {
                byte[] data = System.Convert.FromBase64String(Request.Cookies["Session"].Value);
                MemoryStream ms = new MemoryStream(data);
                BinaryFormatter bf = new BinaryFormatter();
                admin = (AdminModel)bf.Deserialize(ms);
            }
            Label1.Text = "";
            if (admin != null && admin.IsAuth)
            {
                SQLiteConnection connection = new SQLiteConnection("Data Source=C:\\AAAAA\\AAAA\\AAAAAAAAA\\AAAA.AA; Read Only = True;");
                connection.Open();
                String request = "Select flag from secret";
                SQLiteCommand command = new SQLiteCommand(request, connection);
                SQLiteDataReader dataReader = command.ExecuteReader();
                if (dataReader.Read())
                {
                    String flag = (String)dataReader.GetValue(0);
                    Label1.Text = flag;
                }
                dataReader.Close();
                command.Dispose();
                connection.Close();
            }
            else
            {
                Response.Redirect("/Login.aspx");
            }
        }
        else
        {
            Response.Redirect("/Default.aspx");
        }
    }
}
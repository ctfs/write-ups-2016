﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Shit;
using System.Data.SqlClient;

public partial class Login : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if(Request.ServerVariables["REMOTE_ADDR"] == "127.0.0.1")
        {
        if (Request.Form["Username"] != null && Request.Form["Password"] != null)
            {
                AdminModel admin = new AdminModel(Request.Form["Username"], Request.Form["Password"]);
                if (admin.IsAuth)
                {
                    BinaryFormatter bf = new BinaryFormatter();
                    MemoryStream ms = new MemoryStream();
                    bf.Serialize(ms, admin);
                    Response.Cookies["Session"].Value = System.Convert.ToBase64String(ms.GetBuffer());
                    Response.Redirect("/Admin.aspx");
                }
            }
        }
        else
        {
            Response.Redirect("/Default.aspx");
        }
        
    }
}
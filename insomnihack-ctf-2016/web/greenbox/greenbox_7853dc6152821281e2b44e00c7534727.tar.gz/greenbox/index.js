var fs = require('fs');
var express = require('express');
var app = express();
var bodyParser = require('body-parser');
var cp = require('child_process');
var _ = require('lodash');
var crypto = require('crypto');
var uuid = require('node-uuid');

function randomIntInc (low, high) {
    return Math.floor(Math.random() * (high - low + 1) + low);
}

app.set('view engine', 'ejs');
app.set('views', __dirname + '/views')

app.use(bodyParser.json());
app.use(express.static(__dirname + '/bower_components/'));
app.use(express.static(__dirname + '/static/'));

var defaultScript = fs.readFileSync(__dirname + '/example.js').toString();

app.get('/', function (req, res) {
    res.render('index', {script: defaultScript});
});

var startPlant = [{
    'name': 'stem',
    'form': '|',
    'children': []
}];
var startLife = {water: 10, nutrient: 10}


app.post('/', function (req, res) {
    var script = req.body.js;
    var environment = {};
    var currentPlant = JSON.parse(JSON.stringify(startPlant));
    var life = JSON.parse(JSON.stringify(startLife));
    var endError = 'no';
    var hour;
    var nbHour = 0;

    while(nbHour < 24 && endError === 'no'){
        nbHour += 1;
        hour = randomIntInc(0, 24);
        if(hour > 8 && hour < 18){
            environment['light']          = randomIntInc(5, 10);
            environment['temperature']    = randomIntInc(10, 20);
            environment['lightPosition'] = (randomIntInc(1, 2) === 1) ? 'right' : 'left';
        }
        else{
            environment['light']       = randomIntInc(1, 5);
            environment['temperature'] = randomIntInc(1, 10);
            environment['lightPosition'] = 'top';
        }

        if(hour >= 16 && hour <= 18 || hour === 7){
            environment['water'] = randomIntInc(2, 4);
        }
        else{
            environment['water'] = 0;
        }
        
        life['water'] += environment['water'];
        life['nutrient'] -= 1*currentPlant.length;
        life['water'] -= 0.02*environment['light'];
        life['nutrient'] += 0.4*environment['temperature'];
        var stdout = '';
        try{
            stdout = cp.execFileSync('/usr/bin/node', [__dirname + '/vm.js', argvEncode(environment), argvEncode(life), argvEncode(currentPlant), argvEncode(script)], {timeout: 2000});
        }
        catch (err) {
            endError = 'Timed out !';
        }
        
        try{
            if(stdout.length > 0){
                var result = argvDecode(stdout);
            }
            else{
                var result = {verb: 'nop'};
            }
        }
        catch (err) {
            endError = 'Unknown error'
        }
        if(typeof(result) === 'undefined'){
        }
        else if(typeof(result.error) !== 'undefined'){
            endError = result.error;
        }
        else{
            try{
                switch(result.verb){
                    case 'grow':
                        if(environment['light'] > 3 && life['nutrient'] > 6 && life['water'] > 2){
                            grow(currentPlant, environment['lightPosition'], result.args);
                            if(environment['lightPosition'] !== 'top' && environment['lightPosition'] !== result.args['direction']){
                                life['nutrient'] -= 1;
                            }
                            life['nutrient'] -= 2;
                            life['water'] -= 1;
                        }
                        break;
                    case 'fork':
                        if(environment['light'] > 3 && life['nutrient'] > 10 && life['water'] > 4){
                            fork(currentPlant, environment['lightPosition'], result.args);
                            life['nutrient'] -= 5;
                            life['water'] -= 2;
                        }
                        break;
                    case 'bloom':
                        if(environment['light'] > 6 && life['nutrient'] > 20 && life['water'] > 6){
                            bloom(currentPlant, result.args);
                            life['nutrient'] -= 10;
                            life['water'] -= 3;
                        }
                        break;
                    case 'ted':
                        ted(currentPlant, result.args);
                        life['nutrient'] += 11;
                        break;
                    case 'restart':
                        currentPlant = [{
                            'name': 'stem',
                            'form': '|',
                            'children': []
                        }];;
                        life = {water: 10, nutrient: 10};
                        break;
                }
            }
            catch (err) {
                endError = err.message;
            }
        }
    }
    res.json({error: endError, plant: currentPlant, hour:hour});
});

function bloom(plant, args){
    var stem = _.find(plant, 'name', args['stemName']);
    if(stem){
        if(stem.children.length === 0){
            if(stem.form.slice(-1) !== '*'){
                stem.form += '*';
            }
            else{
                throw {name: 'ImpossibleChoice', message: 'Stem "'+stem.name+'" already bloomed.'};
            }
        }
        else{
            throw {name: 'ImpossibleChoice', message: 'Stem "'+stem.name+'" already forked.'};
        }
    }
    else{
        throw {name: 'ImpossibleChoice', message: 'Stem "'+stem.name+'" doesn\'t exist.'};
    }
}

function ted(plant, args){
    var stem = _.find(plant, 'name', args['stemName']);
    if(stem){
        if(stem.form.slice(-1) === '*'){
            stem.form = stem.form.slice(0, -1);
        }
        else{
            throw {name: 'ImpossibleChoice', message: 'Stem "'+stem.name+'" not bloomed.'};
        }
    }
    else{
        throw {name: 'ImpossibleChoice', message: 'Stem "'+stem.name+'" doesn\'t exist.'};
    }
}

function grow(plant, lightPosition, args){
    var stem = _.find(plant, 'name', args['stemName']);
    if(stem){
        if(stem.children.length === 0){
            if(stem.form.slice(-1) !== '*'){
                switch(args['direction']){
                    case 'right':
                        if(lightPosition === 'left'){
                            stem.form += '|';
                        }
                        else{
                            stem.form += '/';
                        }
                        break;
                    case 'left':
                        if(lightPosition === 'right'){
                            stem.form += '|';
                        }
                        else{
                            stem.form += '\\';
                        }
                        break;
                    default:
                        if(lightPosition === 'left'){
                            stem.form += '\\';
                        }
                        else if(lightPosition === 'top'){
                            stem.form += '|';
                        }
                        else{
                            stem.form += '/';
                        }
                        break;
                }
            }
            else{
                throw {name: 'ImpossibleChoice', message: 'Stem "'+stem.name+'" already bloomed.'};
            }

        }
        else{
            throw {name: 'ImpossibleChoice', message: 'Stem "'+stem.name+'" already forked.'};
        }
    }
    else{
        throw {name: 'ImpossibleChoice', message: 'Stem "'+stem.name+'" doesn\'t exist.'};
    }
}

function fork(plant, lightPosition, args){
    var stem = _.find(plant, 'name', args['stemName']);
    if(stem){
        if(stem.children.length === 0){
            if(stem.form.slice(-1) !== '*'){
                stem.form += '=';
                stem.children.push(args['firstChildName']);
                stem.children.push(args['secondChildName']);

                var firstForm = '\\';
                var secondForm = '/';

                switch(lightPosition){
                    case 'right':
                        firstForm = '|';
                        secondForm = '/';
                        break;
                    case 'left':
                        firstForm = '\\';
                        secondForm = '|';
                        break;
                }

                var firstChild = {
                    'name': args['firstChildName'],
                    'form': firstForm,
                    'children': []
                };

                var secondChild = {
                    'name': args['secondChildName'],
                    'form': secondForm,
                    'children': []
                };

                plant.push(firstChild);
                plant.push(secondChild);
            }
            else{
                throw {name: 'ImpossibleChoice', message: 'Stem "'+stem.name+'" already bloomed.'};
            }

        }
        else{
            throw {name: 'ImpossibleChoice', message: 'Stem "'+stem.name+'" already forked.'};
        }
    }
    else{
        throw {name: 'ImpossibleChoice', message: 'Stem "'+stem.name+'" doesn\'t exist.'};
    }
}

function argvEncode(arg){
    return new Buffer(new Buffer(JSON.stringify(arg)).toString('binary')).toString('base64');
}

function argvDecode(arg){
    return JSON.parse(new Buffer(new Buffer(arg, 'base64').toString('binary'), 'base64').toString('binary'));
}

var server = app.listen(8080);

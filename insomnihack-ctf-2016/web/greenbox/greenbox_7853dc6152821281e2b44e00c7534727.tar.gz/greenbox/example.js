var result = {verb: '', args: {}};

if(plant.length === 1 && plant[0].form.length < 6 && environment['light'] > 3 && life['nutrient'] > 6 && life['water'] > 2){
    result.verb = 'grow';
    result.args = {'stemName': 'stem', 'direction': 'top'}
}

if(plant.length > 1 && plant[1].form.length < 6 && environment['light'] > 3 && life['nutrient'] > 6 && life['water'] > 2){
    result.verb = 'grow';
    result.args = {'stemName': 'one', 'direction': 'top'}
}

if(plant.length === 1 && plant[0].form.length > 3 && environment['light'] > 3 && life['nutrient'] > 10 && life['water'] > 4){
    result.verb = 'fork';
    result.args = {'stemName': 'stem', 'firstChildName': 'one', 'secondChildName': 'two'};
}

if(plant.length !== 0 && environment['light'] > 6 && life['nutrient'] > 20 && life['water'] > 6){
    plant.forEach(function(stem){
        if(stem.name === 'two'){
            if(stem.form.slice(-1) === '*'){
                result.verb = 'ted';
            }
            else{
                result.verb = 'bloom';
            }
            result.args = {'stemName': 'two'};
        }
    });
}

// result.verb = 'restart';

result.error = 'Remove this to start';

result;

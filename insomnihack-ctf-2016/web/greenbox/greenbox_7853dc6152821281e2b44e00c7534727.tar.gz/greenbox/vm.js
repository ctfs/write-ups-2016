var vm = require('vm');
// A f*cking security researcher hacked us using process.mainModule to escape the vm.
process.mainModule = {};

function argvDecode(arg){
    return JSON.parse(new Buffer(arg, 'base64').toString('binary'));
}

function argvEncode(arg){
    return new Buffer(new Buffer(JSON.stringify(arg)).toString('binary')).toString('base64');
}

try{
    var environment = argvDecode(process.argv[2]);
    var life = argvDecode(process.argv[3]);
    var plant = argvDecode(process.argv[4]);
    var script = argvDecode(process.argv[5]);

    var sandbox = vm.createContext({Object: null, environment: environment, life: life, plant: plant});
    var myScript = vm.createScript(script);
    var result = myScript.runInNewContext(sandbox, {timeout: 5000});
}
catch(err){
    var result = {
        error: err.message
    };
}

try{
    console.log(argvEncode(result));
}
catch(err){
    var result = {
        error: err.message
    };
    console.log(argvEncode(result));
}
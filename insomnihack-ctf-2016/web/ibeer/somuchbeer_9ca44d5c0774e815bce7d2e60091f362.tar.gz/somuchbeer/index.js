var express = require('express');
var app = express();
var session  = require('express-session');
var http = require('http').Server(app);
var io = require('socket.io')(http);
var url = require('url');
var cookieParse = require('cookie');
var cookieSession = require('cookie-session')
var keygrip = require('keygrip');


var adminSecret = 'You\'ll never find it';
var sessionKey = 'notTooDrunk';
var sessionSecret = ['same here it\'s too complicated'];

app.use(express.static('public'));

app.sessionStore = new session.MemoryStore();
var key = new keygrip(sessionSecret);
app.use(cookieSession({
  'keys': sessionSecret,
  'name'   : sessionKey,
  })
);

app.get('/', function(req, res){
  req.session.auth = false;
  res.sendFile(__dirname+'/index.html');
});

app.get('/admin', function(req, res){
  if(req.session.auth || req.query.secret === adminSecret){
    req.session.auth = true;
    res.sendFile(__dirname+'/index.html');
  }
  else{
    res.sendFile(__dirname+'/login.html');
  }
});


function decode(string) {
  var body = new Buffer(string, 'base64').toString('utf8');
  return JSON.parse(body);
}

io.use(function(socket, next) {
  var room = url.parse(socket.handshake.url, true).query.room;
  if(room === 'admin'){
    var handshake = socket.request;
    if(typeof(handshake.headers.cookie) !== 'undefined'){
      var cookie = cookieParse.parse(handshake.headers.cookie);
      if(typeof(cookie[sessionKey]) !== 'undefined'){
        if(typeof(cookie[sessionKey+'.sig']) !== 'undefined'){
          if(key.sign(sessionKey+'='+cookie[sessionKey]) !== cookie[sessionKey+'.sig']){
            next(new Error('not authorized'));
          }
        }
        var session = decode(cookie[sessionKey]);
        if(session.auth){
          next();
        }
      }
    }
    next(new Error('not authorized'));
  }
  else{
    next();
  }
});


io.on('connection', function(socket){
  var room = url.parse(socket.handshake.url, true).query.room;
  if(typeof(room) === 'undefined' || room.match(/^(\w+)$/) === null) {
    room = 'trash';
  }
  socket.join(room);

  socket.broadcast.to(room).emit('newBeer', socket.conn.id);
  socket.on('disconnect', function(){
    socket.broadcast.to(room).emit('emptyBeer', socket.conn.id);
  });

  socket.on('moveBeer', function(pos){
    pos.id = socket.conn.id;
    socket.broadcast.to(room).emit('moveBeer', pos);
  });

  socket.on('whereAreYou', function(){
    socket.broadcast.to(room).emit('whereAreYou');
  });
});

http.listen(parseInt(process.env.OPENSHIFT_NODEJS_PORT, 10), process.env.OPENSHIFT_NODEJS_IP, function(){
  console.log('listening on ' + process.env.OPENSHIFT_NODEJS_IP + ':' + process.env.OPENSHIFT_NODEJS_PORT);
});

from sqlalchemy import create_engine
from sqlalchemy.orm import scoped_session, sessionmaker
from sqlalchemy.ext.declarative import declarative_base

engine = create_engine('sqlite:////home/secuvps/tmp/database.db', convert_unicode=True)
db_session = scoped_session(sessionmaker(autoflush=True,
                                         bind=engine))
Base = declarative_base()
Base.query = db_session.query_property()

def init_db():
    import models
    Base.metadata.create_all(bind=engine)

import os
if not os.path.isfile('/home/secuvps/tmp/database.db'):
    init_db()


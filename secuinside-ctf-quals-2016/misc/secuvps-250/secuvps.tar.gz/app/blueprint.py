# -*- coding: utf-8 -*-
from flask import Blueprint

class ServiceBlueprint(Blueprint):

    def get(self, rule, **options):
        options['methods'] = ['GET']
        return self.route(rule, **options)

    def post(self, rule, **options):
        options['methods'] = ['POST']
        return self.route(rule, **options)

    def put(self, rule, **options):
        options['methods'] = ['PUT']
        return self.route(rule, **options)

blueprint = ServiceBlueprint('service', __name__, template_folder='templates')

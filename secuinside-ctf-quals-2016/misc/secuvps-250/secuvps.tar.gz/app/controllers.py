from flask import Flask, request, session, redirect, url_for
from flask import render_template
from database import db_session
from models import User, SupportTicket
from hashlib import sha1
import socket
import subprocess
from .blueprint import blueprint
import tempfile
import os

@blueprint.get('/')
def index():
    return render_template('index.html')


@blueprint.get('/login_or_join')
@blueprint.post('/login_or_join')
def login_or_join():
    if request.method == 'POST':
        if request.form['action'] == 'login':
            try:
                user = User.query.filter_by(username=request.form['username'],
                                            password=sha1(request.form['password']).hexdigest()).first()
                session['username'] = user.username
                session['userId'] = user.id
            except:
                return '<script>alert("login error");history.go(-1)</script>'

        elif request.form['action'] == 'join':
            try:
                db_session.add(User(request.form['username'], request.form['password']))
                db_session.commit()
                return '<script>alert("success");history.go(-1)</script>'
            except:
                db_session.rollback()
                return '<script>alert("join error");history.go(-1)</script>'

        return redirect(url_for('service.index'))

    return '<script>history.go(-1)</script>'


@blueprint.get('/logout')
def logout():
    session.pop('username', None)
    session.pop('userId', None)
    return redirect(url_for('service.index'))


@blueprint.get('/dashboard')
def dashboard():
    if 'userId' not in session:
        return redirect(url_for('service.index'))
    return render_template('dashboard.html')


def isAllowedHost(host):
    try:
        host = socket.gethostbyname(host)
        return host.startswith('192.168.')
    except:
        return False


def ssh(host):
    f = tempfile.NamedTemporaryFile(delete=False)
    f.write(file('/home/admin/.ssh/id_ed25519').read())
    fn = f.name
    f.close()
    os.chmod(fn, 384)
    try:
        return subprocess.check_output(['/home/admin/runas', '/usr/bin/timeout', '-s', 'KILL', '4', 
                                        '/home/admin/secussh/ssh', '-o', 'UserKnownHostsFile=/dev/null', '-o', 'StrictHostKeyChecking=no', '-o', 'BatchMode=yes', '-i', fn, host, 'secuvps-check'], stderr=subprocess.STDOUT)
    except subprocess.CalledProcessError as e:
        return e.output
    except Exception as e:
        return repr(e)
    finally:
        try:
            os.unlink(fn)
        except:
            pass


def curl(host):
    try:
        return subprocess.check_output(['/home/admin/runas', '/usr/bin/timeout', '-s', 'KILL', '2', 
                                        '/usr/bin/curl', host], stderr=subprocess.STDOUT)
    except subprocess.CalledProcessError as e:
        return e.output
    except Exception as e:
        return repr(e)


@blueprint.get('/support')
@blueprint.post('/support')
def support():
    if 'userId' not in session:
        return redirect(url_for('service.index'))

    if request.method == 'POST':
        type_ = request.form['type']
        host = request.form['arg']
        
        result = 'Host not allowed (' + socket.gethostbyname(host) + ')'
        if isAllowedHost(host):
            if type_ == 'ssh':
                result = ssh(host)
            elif type_ == 'web':
                result = curl(host)

        if not result:
            result = 'Fail'

        try:
            db_session.add(SupportTicket('Closed',
                                         session['userId'],
                                         type_,
                                         host,
                                         result))
            db_session.commit()
        except:
            db_session.rollback()

        return redirect(url_for('service.tickets'))

    return render_template('support.html')


@blueprint.get('/reopen_ticket/<int:ticket_id>')
def reopen_ticket(ticket_id):
    ticket = SupportTicket.query.filter_by(id=ticket_id).first()

    result = 'N/A'
    if ticket.type_ == 'ssh':
        result = ssh(ticket.target)
    elif ticket.type_ == 'web':
        result = curl(ticket.target)

    try:
        db_session.add(SupportTicket('Reopened (#%d)' % ticket_id,
                                     session['userId'],
                                     ticket.type_,
                                     ticket.target,
                                     result))
        db_session.commit()
    except:
        db_session.rollback()

    return redirect(url_for('service.tickets'))


@blueprint.get('/tickets')
def tickets():
    if 'userId' not in session:
        return redirect(url_for('service.index'))
    return render_template('tickets.html', tickets=SupportTicket.query.filter_by(userId=session['userId']))


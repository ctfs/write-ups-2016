# -*- coding:utf-8 -*-
import os
from flask import Flask, abort, redirect, url_for

def create_app():
    project_root = '/home/secuvps'
    template_folder = os.path.join(project_root, 'service/templates')
    static_folder = os.path.join(project_root, 'service/static')

    app = Flask(__name__, template_folder=template_folder, static_folder=static_folder)

    if not os.path.isfile('/home/secuvps/tmp/secret_key'):
        file('/home/secuvps/tmp/secret_key', 'w').write(os.urandom(24))
    app.secret_key = file('/home/secuvps/tmp/secret_key').read()
    __import__('service.app.controllers', 'controllers', fromlist=['controllers'])
    blueprint_module = __import__('service.app.blueprint', 'blueprint', fromlist=['blueprint'])
    blueprint = getattr(blueprint_module, 'blueprint')
    app.register_blueprint(blueprint)
    return app

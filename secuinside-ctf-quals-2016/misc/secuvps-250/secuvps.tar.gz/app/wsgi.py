# -*- coding:utf-8 -*-
from service.app import create_app

app = create_app()

from sqlalchemy import Column, Integer, String
from database import Base
from hashlib import sha1


class User(Base):
    __tablename__ = 'users'
    id = Column(Integer, primary_key=True)
    username = Column(String(128), unique=True)
    password = Column(String(40))

    def __init__(self, username=None, password=None):
        self.username = username
        self.password = sha1(password).hexdigest()

    def __repr__(self):
        return self.username


class SupportTicket(Base):
    __tablename__ = 'tickets'
    id = Column(Integer, primary_key=True)
    status = Column(String(16))
    userId = Column(Integer)
    type_ = Column(String(16))
    target = Column(String(256))
    result = Column(String(4096))

    def __init__(self, status, userId, type_, target, result):
        self.status = status
        self.userId = userId
        self.type_ = type_
        self.target = target
        self.result = result

    def __repr__(self):
        return '#%d Status: %s (%s %s) : %s' % (self.id, self.status, self.type_, self.target, self.result)

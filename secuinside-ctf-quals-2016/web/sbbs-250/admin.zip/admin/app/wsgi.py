# -*- coding:utf-8 -*-
from admin.app import create_app

app = create_app()

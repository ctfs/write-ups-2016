# -*- coding: utf-8 -*-
from utils.blueprint import ServiceBlueprint

blueprint = ServiceBlueprint('admin', __name__, template_folder='templates')

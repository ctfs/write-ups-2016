#ifndef __STD_H__
#define __STD_H__

#include <iostream>
#include <map>
#include <string>
#include <memory>
#include <vector>
#include <utility>
#include <unistd.h>

#endif
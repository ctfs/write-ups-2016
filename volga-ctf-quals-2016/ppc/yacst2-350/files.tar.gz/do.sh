sox $1 -n spectrogram -Y 130 -l -r -o $1.png || exit
#convert $1.png -colorspace gray  +dither  -colors 2  -normalize -crop 100000x100+0+0 gray.$1.png
convert $1.png -colorspace gray  -colors 2  -normalize -crop 100000x80+0+0 gray.$1.png

IN=gray.$1

python3 split.py gray.$1.png | (let imgn=0; while read eh begin end; do

  echo "EH $begin $end"
   convert $IN.png -crop $(($end-$begin))x80+$begin+0 -resize 50x80\! out.$IN.$imgn.png;

  let imgn++
done; )

for sym in $(seq 0 4); do
  rm test.png
  for s in $(seq 0 9); do
    composite out.$IN.$sym.png S$s.png -compose difference test.png
    whites=$(convert test.png -define histogram:unique-colors=true -format %c histogram:info:- | grep '255,255,255' | awk -F: '{print $1}')
    echo 0$(echo -ne $whites | tr -d ' \t') $s
  done | sort -n | head -n1 | cut -d' ' -f2
done

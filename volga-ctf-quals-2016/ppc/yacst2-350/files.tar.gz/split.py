from PIL import Image
import sys

im = Image.open(sys.argv[1])

whiteOnly = True

start = 0

for x in range(im.size[0]):
    newWhiteOnly = True
    for y in range(im.size[1]):
        if im.getpixel((x,y)) == 0:
            newWhiteOnly = False
            break

    if whiteOnly and not newWhiteOnly:
        start = x
    elif not whiteOnly and newWhiteOnly:
        print("img", start, x)

    whiteOnly = newWhiteOnly

Scrambling:
F' D' U' L' U' F2 B2 D2 F' U D2 B' U' B2 R2 D2 B' R' U B2 L U R' U' L'


White side:
-------
|{|3| |
| |D|R|
| |W| |
-------

Orange side:
-------
| | | |
| | | |
| | | |
-------

Yellow side:
-------
|}| | |
|3| | |
| | | |
-------


Red side:
-------
|I| | |
| | | |
| | |C|
-------

Green side:
-------
| | | |
| | | |
| | | |
-------

Blue side:
-------
| | | |
| | | |
| | | |
-------

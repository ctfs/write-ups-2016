package main

import (
	"encoding/hex"
	"errors"
        "fmt"
	"io"
        "bytes"
	"io/ioutil"
	"net/http"
        "github.com/spacemonkeygo/openssl"
        "os"
        "crypto/aes"
)

const GCMTagLength = 2

/* 2 bytes is a little short, but the chance of forging is still 1/2^16, so it
 * should be fine. */

func encrypt(key, iv, plaintext []byte) ([]byte, []byte, error) {
        returnee := new(bytes.Buffer)
        ectx, err := openssl.NewGCMEncryptionCipherCtx(256, nil, key, iv)
        if err != nil {
                return nil, nil, err
        }
        moar, err := ectx.EncryptUpdate(plaintext)
        if err != nil {
                return nil, nil, err
        }
        returnee.Write(moar)
        moar2, err := ectx.EncryptFinal()
        if err != nil {
                return nil, nil, err
        }
        returnee.Write(moar2)
        tag, err := ectx.GetTag()
        if err != nil {
                return nil, nil, err
        }
        return returnee.Bytes(), tag[:GCMTagLength], nil
}

func decrypt(key, iv, ciphertext, tag []byte) ([]byte, error) {
        returnee := new(bytes.Buffer)
        dctx, err := openssl.NewGCMDecryptionCipherCtx(256, nil, key, iv)
        if err != nil {
                return nil, err
        }
        moar, err := dctx.DecryptUpdate(ciphertext)
        if err != nil {
                return nil, err
        }
        returnee.Write(moar)
        err = dctx.SetTag(tag)
        if err != nil {
                return nil, err
        }
        result, err := dctx.DecryptFinal()
        if err != nil {
                return nil, err
        }
        returnee.Write(result)
        return returnee.Bytes(), nil
}

var key []byte

func decrypto(w http.ResponseWriter, r *http.Request) {
        body, err := ioutil.ReadAll(r.Body)
        if err != nil {
                http.Error(w, "An error occurred", 500)
                return
        }
        if len(body) < 12 + GCMTagLength {
                http.Error(w, "Ciphertext too short", 400)
                return
        }
        iv := body[:12]
        c := body[12:len(body)-GCMTagLength]
        t := body[len(body)-GCMTagLength:]
        result, err := decrypt(key, iv, c, t)
        if err != nil {
                http.Error(w, "Bad auth tag", 400)
                return
        }
        io.WriteString(w, string(result))
}

func test() {
        iv := []byte("1324352634")
        plaintext := []byte("A man, a plan, a canal, Panama")
        ciphertext, tag, err := encrypt(key, iv, plaintext)
        if err != nil {
                fmt.Println("error1")
                fmt.Println(err.Error())
                return
        }
        checktext, err := decrypt(key, iv, ciphertext, tag)
        if err != nil {
                fmt.Println("error2")
                return
        }
        if bytes.Compare(plaintext, checktext) != 0 {
                fmt.Println("fail")
                return
        }
        if len(tag) != GCMTagLength {
                fmt.Println("bad tag")
                return
        }
        fmt.Println("success")
}

func load_key() {
        hexxx, err := ioutil.ReadFile("key.txt")
        if err != nil {
                panic(err)
        }
        array, err := hex.DecodeString(string(hexxx[:64]))
        if err != nil {
                panic(err)
        }
        if len(array) != 32 {
                panic(errors.New("Bad key length"))
        }
        key = array
}

func generate_sample() {
        iv := []byte("fantastic iv")
        message, err := ioutil.ReadFile("plaintext")
        if err != nil {
                panic(err)
        }
        ciphertext, tag, err := encrypt(key, iv, message)
        if err != nil {
                panic(err)
        }
        err = ioutil.WriteFile("ciphertext", ciphertext, os.ModePerm)
        if err != nil {
                panic(err)
        }
        fmt.Println("iv:", iv)
        fmt.Println("tag:", tag)
}

func print_flag() {
        c, _ := aes.NewCipher(key)
        ciph := []byte("\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000")
        c.Encrypt(ciph, []byte("\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"))
        fmt.Printf("flag:  BKPCTF{%s}\n", hex.EncodeToString(ciph))
}

func main() {
        load_key()
        test()
        generate_sample()
        print_flag()
	http.HandleFunc("/decrypt/", decrypto)
	http.ListenAndServe(":8000", nil)
}

from flask import Flask
from flask import session, request, redirect, render_template, url_for, send_from_directory
import os, sys


AUTHFILE = 'passwd'
SALT = os.environ['TW_SALT']

app = Flask('Tsurai Web', static_folder='templates/assets')
app.config['SECRET_KEY'] = os.environ['TW_SECRET']

sys.path.append('data')

@app.route('/')
def index():
    if not session.get('username'):
        return render_template('index.html')

    config = __import__(h(session.get('username')))
    password = request.args.get('password')
    msg = request.args.get('msg')

    if password:
        return render_template('albums.html', 
                msg="Your password is {}".format(password),
                imgs=config.imgs)
    elif msg:
        return render_template('albums.html', 
                msg=msg,
                imgs=config.imgs)
    else:
        return render_template('albums.html', 
                msg="Hello, {} !".format(session.get('username')),
                imgs=config.imgs)


@app.route('/login', methods=['POST'])
def login():
    username = request.form['username']
    password = request.form['password']

    if auth(username, password):
        session['username'] = username
        return redirect('/')
    else:
        return render_template('index.html', error="Login failed.")


@app.route('/logout')
def logout():
    session.pop('username', None)
    return redirect('/')


@app.route('/register', methods=['POST'])
def register():
    username = request.form['username']

    if not is_valid(username):
        return render_template('index.html', error="Invalid username.")

    if user_exists(username):
        return render_template('index.html', error="User already exists.")

    password = genpw()
    hashed = h(password+SALT)
    open(AUTHFILE, 'a').write('\n{username}:{hashed}'.format(**locals()))
    os.mkdir('data/{}'.format(h(username)))
    open('data/{}.py'.format(h(username)), 'w').write("imgs = {}".format(repr([])))

    session['username'] = username
    
    return redirect('/?password='+password)


@app.route('/upload', methods=['POST'])
def upload():
    if not session.get('username'):
        return redirect('/')

    if 'file' not in request.files:
        redirect('/?msg='+q("No file specified."))

    config = __import__(h(session.get('username')))
    imgs = config.imgs

    req_file = request.files['file']

    if not req_file or req_file.filename == "":
        return redirect('/?msg='+q("No file specified."))

    fname = req_file.filename

    if fname in imgs:
        return redirect('/?msg='+q('File already exists.'))

    imgs.append(fname)
    req_file.save(os.path.join("data/{}".format(h(session.get('username'))), os.path.basename(fname)))
    open("data/{}.py".format(h(session.get('username'))), 'w').write("imgs = {}".format(repr(imgs)))

    return redirect('/?msg='+q("Upload succeccful."))


@app.route('/show')
def show():
    if not session.get('username'):
        return redirect('/')

    filename = request.args.get('filename')
    return send_from_directory("data/{}".format(h(session.get('username'))), filename)


def is_valid(username):
    import re
    if not re.match(r"\A[0-9a-zA-Z]{,20}\Z", username):
        return False
    else:
        return True


def user_exists(username):
    auths = open(AUTHFILE).read().strip().split('\n')
    for l in auths:
        if ':' not in l:
            continue
        u, _ = l.split(':', 1)
        if u == username:
            return True
    return False


def auth(username, password):
    auths = open(AUTHFILE).read().strip().split('\n')
    for l in auths:
        if ':' not in l:
            continue
        u, p = l.split(':', 1)
        hashed = h(password+SALT)
        if (u, p) == (username, hashed):
            return True

    return False


def h(s):
    from hashlib import md5
    return md5(s).hexdigest()


def q(s):
    from urllib import quote
    return quote(s)


def genpw():
    import random, string
    return ''.join([random.choice(string.printable[:62]) for _ in range(0x10)])


if __name__ == '__main__':
    app.run()

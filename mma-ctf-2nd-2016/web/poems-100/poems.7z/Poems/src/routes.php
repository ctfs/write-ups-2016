<?php

function check_poem_id($id) {
  // Evil
  if(strpos($id, 'list.txt') !== FALSE) {
    return false;
  }
  return true;
}
// Routes
$app->get('/', function ($request, $response, $args) {
  return $this->renderer->render($response, 'index.phtml');
});

$app->get('/poems', function($request, $response, $args) {
  $poem_id = $request->getQueryParams()['p'];
  $poem_path = $this->get('settings')['poems']['path'];
  if(check_poem_id($poem_id) === false) {
    $response->getBody()->write("Error");
    return $response;
  }
  $poem = file_get_contents($poem_path . '/data/' . $poem_id) ;
  if($poem === FALSE || empty($poem_path)) {
    $response->getBody()->write("Error");
    return $response;
  }
  if(json_decode($poem) === NULL) {
    $response->getBody()->write("Invalid json, please contact administrator\nContent: " . $poem);
    return $response;
  }
  return $this->renderer->render($response, 'poem.phtml', json_decode($poem, true));
});

$app->get('/admin', function($request, $response, $args) {
  $page = (int)$request->getQueryParams()['p'];
  if(!$page) {
    $page = 1;
  }
  $page -= 1;
  $poems = [];
  $poem_path = $this->get('settings')['poems']['path'];
  $fp = fopen($poem_path . '/list.txt', 'r');
  for($skip = 0; $skip < 50 * ($page); $skip++) {
    fgets($fp);
  }
  for($row = 0; $row < 50; $row++) {
    $data = fgets($fp);
    if($data) $poems[] = $data;
  }
  return $this->renderer->render($response, 'admin.phtml', ['poems' => $poems, 'page' => $page]);
});

$app->post('/', function ($request, $response, $args) {
  $parsedBody = $request->getParsedBody();
  $data = [
    'name' => (string)$parsedBody['name'],
    'poem' => (string)$parsedBody['poem'],
  ];
  if(empty($data['name']) || empty($data['poem'])) {
    return $this->renderer->render($response, 'index.phtml', ['error' => 'Please input Name and Poem!']);
  }
  $filename = bin2hex(random_bytes(16));
  $poem_path = $this->get('settings')['poems']['path'];
  $fp = fopen($poem_path . '/list.txt', 'a');
  fwrite($fp, $filename . "\n");
  fclose($fp);
  file_put_contents($poem_path . '/data/' . $filename, json_encode($data));
  return $response->withRedirect('/poems?p=' . $filename);
});

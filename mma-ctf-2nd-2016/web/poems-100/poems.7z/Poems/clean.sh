#!/bin/sh
rm -f poems/data/*
rm poems/list.txt
touch poems/list.txt
chmod 777 poems/list.txt
chmod 777 poems/data

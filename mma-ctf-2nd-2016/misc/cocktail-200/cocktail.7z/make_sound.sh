say "The flag of part 1 is * * * * * * * * * * * * * * * *" -o part1.aiff -v voice1
say "The flag of part 2 is * * * * * * * * * * * * * * * *" -o part2.aiff -v voice2
say "The flag of part 3 is * * * * * * * * * * * * * * * *" -o part3.aiff -v voice3
say "The flag of part 4 is * * * * * * * * * * * * * * * *" -o part4.aiff -v voice4
say "The flag of part 5 is * * * * * * * * * * * * * * * *" -o part5.aiff -v voice5
say "The flag of part 6 is * * * * * * * * * * * * * * * *" -o part6.aiff -v voice6
say "The flag of part 7 is * * * * * * * * * * * * * * * *" -o part7.aiff -v voice7
say "The flag of part 8 is * * * * * * * * * * * * * * * *" -o part8.aiff -v voice8
say "TWCTF opening brace, ascii string converted from hex numbers, closing brace" -o part9.aiff -v voice9

for i in `seq 1 9`
do
  ffmpeg -y -i part${i}.aiff part${i}.wav
  rm -f part${i}.aiff
done

python make_whitenoise.py
python mixing_wave.py

#!/bin/bash
cd $(dirname "$0")
/usr/bin/ruby2.0 $1.rb 2> /dev/null | head --bytes=512 # Ubuntu 14.04(64bit) ruby2.0 package

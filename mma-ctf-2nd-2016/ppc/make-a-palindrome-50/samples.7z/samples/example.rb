# this is server connection example
# For ruby >= 1.9
require 'socket'

host = ARGV[0] || 'ppc1.chal.ctf.westerns.tokyo'
port = ARGV[1] || 31111

TCPSocket.open(host, port) do |socket|
  # ignore default messages
  true while socket.gets.chomp != "Let's play!"
  socket.gets
  # 30 cases
  30.times do |caze|
    socket.gets # Case
    words = socket.gets.split[2..-1] # Input
    # words is input data(Array)
    STDOUT.puts "Input: #{words.join(' ')}"
    #
    # Please write some code here.
    #
    answer = words

    # variable answer is your answer(Array)
    STDOUT.puts "Answer: #{answer.join(' ')}"
    socket.puts answer.join(' ')
    STDOUT.puts socket.gets[8..-1] # skip Answer: 
    if /Wrong/ =~ $_
      puts socket.gets
      exit 0
    end
  end
end

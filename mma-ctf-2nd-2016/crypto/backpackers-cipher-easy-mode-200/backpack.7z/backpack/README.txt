ruby cipher.rb genkey pubkey privkey
ruby cipher.rb encrypt pubkey message encrypted

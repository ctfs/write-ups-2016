<?php
setcookie("JSESSION", "", -1, "/");
header("Location: /");
